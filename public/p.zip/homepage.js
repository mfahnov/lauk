$(document).ready(function(){
    $('.slider').bxSlider({
        auto: true,
        pause: 2000,
        mode: 'fade', 
        speed: 500, 
        controls: true, 
        pager: false,
        infiniteLoop: true, 
        autoHover: true,
    });
});
