<?php

use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../storage/framework/maintenance.php')) {
    require $maintenance;
}

// Display the landing page from a specific folder...
$landing_page_path = __DIR__.'/../landing/index.html'; // Change this to the correct path
$landing_page = file_get_contents($landing_page_path);

echo $landing_page;